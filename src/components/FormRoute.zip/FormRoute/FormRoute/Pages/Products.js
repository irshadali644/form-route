function Products (){
    return (
        <div>
            <h2>products page</h2>
        </div>
    )
}
export default Products